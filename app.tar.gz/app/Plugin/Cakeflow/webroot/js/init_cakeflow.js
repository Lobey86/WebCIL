$(document).ready(function(){
    $('.infobulle').tooltip();
});