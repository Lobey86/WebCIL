<?php
class Signature extends CakeflowAppModel
{
    public $tablePrefix = 'wkf_';
//    public $belongsTo = array('Cakeflow.Visa');
}