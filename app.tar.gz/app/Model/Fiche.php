<?php
App::uses('AppModel', 'Model');

class Fiche extends AppModel {
    public $name = 'Fiche';
}