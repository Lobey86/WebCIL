<?php
class RegistresController extends AppController {

    public function index(){

    }


}
