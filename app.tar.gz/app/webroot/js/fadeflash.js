/**
 * Created by aurelien on 11/06/14.
 */
$(document).ready(function(){
    // fade out good flash messages after 3 seconds
    $('.alert').animate({opacity: 1.0}, 3000).fadeOut();
});
/**
 * Created by aurelien on 11/06/14.
 */
